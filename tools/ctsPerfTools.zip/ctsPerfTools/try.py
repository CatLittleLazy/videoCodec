# coding:utf-8
#!/usr/bin/python3
import sys
sys.path.append('../')
if __name__ == '__main__':
	mytype = raw_input()
	print(type(mytype))
	adb pull /data/app/~~S7cRYjMmmx9JD9jRylW2oQ==/net.openvpn.openvpn-Q9bM7FxkSyOu7Bn5WWdlyw==/split_config.ar.apk
	adb pull /data/app/~~S7cRYjMmmx9JD9jRylW2oQ==/net.openvpn.openvpn-Q9bM7FxkSyOu7Bn5WWdlyw==/split_config.ar.apk
	adb pull /data/app/~~S7cRYjMmmx9JD9jRylW2oQ==/net.openvpn.openvpn-Q9bM7FxkSyOu7Bn5WWdlyw==/split_config.ar.apk
	adb pull /data/app/~~S7cRYjMmmx9JD9jRylW2oQ==/net.openvpn.openvpn-Q9bM7FxkSyOu7Bn5WWdlyw==/split_config.ar.apk
	adb pull /data/app/~~S7cRYjMmmx9JD9jRylW2oQ==/net.openvpn.openvpn-Q9bM7FxkSyOu7Bn5WWdlyw==/split_config.ar.apk
	adb pull /data/app/~~S7cRYjMmmx9JD9jRylW2oQ==/net.openvpn.openvpn-Q9bM7FxkSyOu7Bn5WWdlyw==/split_config.zh.apk